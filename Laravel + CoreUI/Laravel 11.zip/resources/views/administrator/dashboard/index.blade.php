@extends('layout.main')
@section('css')
    <style>
        .wellcome {
            height: 75vh;
        }

        .cube-logo {
            width: 60px;
            height: 60px;
            opacity: 0.8;
        }
    </style>
@endsection
@section('content')
    <div class="d-flex justify-content-center align-items-center wellcome">
        <div class="text-center">
            <img class="mb-3 cube-logo" src="{{ asset('/favicon.svg') }}" alt="">
            <h4>Dashboard</h4>
            <small>Selamat datang dihalaman dashboard</small>
        </div>
    </div>
@endsection
@section('js')
    <script></script>
@endsection

@extends('layout.main')
@section('css')
    <style>

    </style>
@endsection
@section('content')
    <div class="title-menu">
        <div>
            <h3 class="fw-normal">Profile</h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a class="text-decoration-none" href="#">Home</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Profile</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <div class="row justify-content-between align-items-center">
                <div class="col-auto">
                    <h5 class="fw-normal mb-0">Data Profile</h5>
                </div>
                <div class="col-auto">
                    <a href="{{ route('profile.edit') }}" class="btn btn-warning">
                        <i class="icon cil-equalizer me-2"></i> Edit
                    </a>
                </div>
            </div>
            <div class="row my-3">
                <div class="col-xl-auto">
                    <div class="row mx-0">
                        <label for="name" class="col-auto col-form-label">
                            <i class="icon cil-caret-right me-2"></i> Name
                        </label>
                        <div class="col">
                            <input type="text" readonly class="form-control-plaintext" id="name"
                                value="{{ $profile->name }}">
                        </div>
                    </div>
                </div>
                <div class="col-xl-auto">
                    <div class="row mx-0">
                        <label for="username" class="col-auto col-form-label">
                            <i class="icon cil-caret-right me-2"></i> Username
                        </label>
                        <div class="col">
                            <input type="text" readonly class="form-control-plaintext" id="username"
                                value="{{ $profile->username }}">
                        </div>
                    </div>
                </div>
                <div class="col-xl-auto">
                    <div class="row mx-0">
                        <label for="email" class="col-auto col-form-label">
                            <i class="icon cil-caret-right me-2"></i> Email
                        </label>
                        <div class="col">
                            <input type="text" readonly class="form-control-plaintext" id="email"
                                value="{{ $profile->email }}">
                        </div>
                    </div>
                </div>
                <div class="col-xl-auto">
                    <div class="row mx-0">
                        <label for="password" class="col-auto col-form-label">
                            <i class="icon cil-caret-right me-2"></i> Password
                        </label>
                        <div class="col">
                            <input type="text" readonly class="form-control-plaintext" id="password"
                                value="{{ $profile->password }}">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('js')
    @if (session()->has('dataSaved') && session()->get('dataSaved') == true)
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: '{{ session()->get('message') }}',
            });
        </script>
    @endif
    @if (session()->has('dataSaved') && session()->get('dataSaved') == false)
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: '{{ session()->get('message') }}',
            });
        </script>
    @endif
@endsection

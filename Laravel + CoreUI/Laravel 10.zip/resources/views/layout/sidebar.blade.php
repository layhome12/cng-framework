<div class="sidebar-header justify-content-center border-bottom">
    <div class="sidebar-brand">
        <div class="sidebar-brand-full">
            <h5 class="text-uppercase text-primary">App Name</h5>
        </div>
    </div>
</div>
<ul class="sidebar-nav" data-coreui="navigation" data-simplebar="">
    <li class="nav-item">
        <a class="nav-link {{ request()->is('admin/dashboard') ? 'active' : '' }}" href="{{ route('dashboard') }}">
            <i class="icon icon-lg cil-home me-3"></i> Dashboard
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{ Route::is('user.*') ? 'active' : '' }}" href="{{ route('user.index') }}">
            <i class="icon icon-lg cil-menu me-3"></i> User
        </a>
    </li>
</ul>

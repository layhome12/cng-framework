<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta name="theme-color" content="#ffffff">
    <title>Laravel 10</title>

    <link rel="shortcut icon" href="{{ asset('/favicon.svg') }}" type="image/x-icon">

    <!-- Vendors styles-->
    <link href="{{ asset('assets/vendors/simplebar/simplebar.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/vendors/sweetalert/sweetalert.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/vendors/coreui/icons/css/free.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/vendors/fontawesome/css/all.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/simplebar.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/datatable.css') }}" rel="stylesheet">

    <!-- Main styles for this application-->
    <link href="{{ asset('assets/css/style.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/custom.css') }}" rel="stylesheet">

    {{-- CSS --}}
    @yield('css')
</head>

<body>
    <div class="sidebar sidebar-light sidebar-fixed border-end" id="sidebar">
        @include('layout.sidebar')
    </div>
    <div class="wrapper d-flex flex-column min-vh-100">
        <header class="header header-sticky p-0 mb-4">
            <div class="container-fluid px-4">
                <button class="header-toggler" type="button"
                    onclick="coreui.Sidebar.getInstance(document.querySelector('#sidebar')).toggle()"
                    style="margin-inline-start: -14px;">
                    <i class="icon icon-lg cil-menu"></i>
                </button>
                <ul class="header-nav">
                    <li class="nav-item dropdown">
                        <button class="btn btn-link nav-link py-2 px-2 d-flex align-items-center" type="button"
                            aria-expanded="false" data-coreui-toggle="dropdown">
                            <div class="theme-icon-active">
                                <i class="icon icon-lg cil-contrast"></i>
                            </div>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" style="--cui-dropdown-min-width: 8rem;">
                            <li>
                                <button class="dropdown-item d-flex align-items-center" type="button"
                                    data-coreui-theme-value="light">
                                    <i class="icon cil-sun me-3"></i> Light
                                </button>
                            </li>
                            <li>
                                <button class="dropdown-item d-flex align-items-center" type="button"
                                    data-coreui-theme-value="dark">
                                    <i class="icon cil-moon me-3"></i> Dark
                                </button>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item py-1">
                        <div class="vr h-100 mx-2 text-body text-opacity-75"></div>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link py-0 pe-0" data-coreui-toggle="dropdown" href="#" role="button"
                            aria-haspopup="true" aria-expanded="false">
                            <div class="avatar avatar-md">
                                <img class="avatar-img" src="{{ asset('assets/img/placeholder.jpg') }}" alt="profile">
                            </div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end pt-0">
                            <div
                                class="dropdown-header bg-body-tertiary text-body-secondary fw-semibold rounded-top mb-2">
                                Setting Akun
                            </div>
                            <a class="dropdown-item" href="{{ route('profile.index') }}">
                                <i class="icon cil-user me-2"></i> Profile
                            </a>
                            <a class="dropdown-item" href="{{ route('logout') }}">
                                <i class="icon cil-account-logout me-2"></i> Logout
                            </a>
                        </div>
                    </li>
                </ul>
            </div>
        </header>
        <div class="body flex-grow-1">
            <div class="px-4">
                {{-- View Render --}}
                @yield('content')
            </div>
        </div>
        <footer class="footer px-4">
            <div class="ms-auto">Powered by <a class="text-decoration-none" href="#">Cegeh Ngoding</a></div>
        </footer>
    </div>

    <!-- CoreUI and necessary plugins-->
    <script src="{{ asset('assets/js/config.js') }}"></script>
    <script src="{{ asset('assets/js/color-modes.js') }}"></script>
    <script src="{{ asset('assets/js/cookies.js') }}"></script>
    <script src="{{ asset('assets/vendors/coreui/core/coreui.bundle.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/simplebar/simplebar.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/jquery/jquery.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/datatable/datatable.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/datatable/datatable.bs5.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/sweetalert/sweetalert.min.js') }}"></script>

    <!-- Plugins and scripts required by this view-->
    <script src="{{ asset('assets/vendors/coreui/utils/index.js') }}"></script>
    <script>
         const baseUrl = (path, prefix = "/admin") => "{{ url('/') }}" + prefix + path;
        const assetUrl = (path) => "{{ asset('/') }}" + path;
    </script>

    {{-- JS --}}
    @yield('js')
</body>

</html>

@extends('layout.main')
@section('css')
    <style>
        .card-icon-bg i {
            font-size: 32px;
            margin-right: 8px;
        }
    </style>
@endsection

@section('content')
    <div class="breadcrumb">
        <h1 class="mr-2">Dashboard</h1>
        <ul>
            <li>
                <a href="#">Home</a>
            </li>
            <li>Dashboard</li>
        </ul>
    </div>
    <div class="separator-breadcrumb border-top"></div>
    <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body align-items-center">
                    <i class="cil-bolt text-primary"></i>
                    <div class="content mx-2">
                        <p class="text-muted mt-2 mb-0">Data #1</p>
                        <p class="text-primary text-24 line-height-1 mb-2">205</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body align-items-center">
                    <i class="cil-bolt text-primary"></i>
                    <div class="content mx-2">
                        <p class="text-muted mt-2 mb-0">Data #2</p>
                        <p class="text-primary text-24 line-height-1 mb-2">100</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body align-items-center">
                    <i class="cil-bolt text-primary"></i>
                    <div class="content mx-2">
                        <p class="text-muted mt-2 mb-0">Data #3</p>
                        <p class="text-primary text-24 line-height-1 mb-2">120</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                <div class="card-body align-items-center">
                    <i class="cil-bolt text-primary"></i>
                    <div class="content mx-2">
                        <p class="text-muted mt-2 mb-0">Data #4</p>
                        <p class="text-primary text-24 line-height-1 mb-2">190</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-8 col-md-12">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Chart Bars</div>
                    <div id="echartBar" style="height: 300px;"></div>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-12">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">Chart Pie</div>
                    <div id="echartPie" style="height: 300px;"></div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script src="{{ asset('assets/js/plugins/echarts.min.js') }}"></script>
    <script src="{{ asset('assets/js/scripts/dashboard.script.js') }}"></script>
@endsection

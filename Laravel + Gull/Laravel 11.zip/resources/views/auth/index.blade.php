<!DOCTYPE html>

<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laravel 11</title>

    <link rel="shortcut icon" href="{{ asset('/favicon.svg') }}" type="image/x-icon">

    <!-- Vendors styles-->
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,400i,600,700,800,900" rel="stylesheet">
    <link href="{{ asset('assets/icons/coreui/css/free.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/icons/fontawesome/css/all.min.css') }}" rel="stylesheet">

    <!-- Main styles for this application-->
    <link href="{{ asset('assets/css/themes/lite-purple.min.css') }}" rel="stylesheet">
</head>

<body>
    <div class="auth-layout-wrap">
        <div class="auth-content">
            <div class="card o-hidden">
                <div class="row">
                    <div class="col-md-6">
                        <div class="p-4">
                            <div class="auth-logo text-center mb-3">
                                <img src="{{ asset('favicon.svg') }}" style="width: 60px; height:60px;" alt="">
                            </div>

                            <h1 class="mb-3 text-18">Sign In</h1>

                            @error('auth_failed')
                                <div class="alert alert-danger" role="alert">
                                    Email atau password anda salah
                                    <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            @enderror

                            <form action="{{ route('authenticate') }}" method="post">
                                @csrf
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input class="form-control form-control-rounded" type="email" name="email"
                                        placeholder="Masukkkan Email" value="{{ old('email') }}">
                                    @error('email')
                                        <small class="text-danger">{{ $message }}</small>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input class="form-control form-control-rounded" type="password" name="password"
                                        placeholder="Masukkan Password" value="{{ old('password') }}">
                                    @error('password')
                                        <small class="text-danger">{{ $message }}</small>
                                    @enderror
                                </div>
                                <div class="my-3 pt-2">
                                    <button class="btn btn-rounded btn-primary btn-block">
                                        <i class="fa fa-sign-in-alt mr-1"></i> Sign In
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-md-6 bg-primary">
                        <div class="pr-3 auth-right text-white">
                            <div>
                                <h2 class="text-white mb-3">
                                    <i class="cil-3d mr-2"></i> Laravel
                                </h2>
                                <p>
                                    Aplikasi ini dibuat menggunakan framework Laravel 11, untuk dokumentasi lebih
                                    lanjut klik tombol dibawah ini.
                                </p>
                                <a href="https://laravel.com/docs/11.x/releases"
                                    class="btn btn-secondary btn-rounded px-4">
                                    Dokumentasi
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="{{ asset('assets/js/plugins/jquery-3.3.1.min.js') }}"></script>
    <script src="{{ asset('assets/js/plugins/bootstrap.bundle.min.js') }}"></script>
</body>

</html>

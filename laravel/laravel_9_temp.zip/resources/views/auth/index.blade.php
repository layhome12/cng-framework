<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta name="theme-color" content="#ffffff">
    <title>Laravel 9</title>

    <link rel="shortcut icon" href="{{ asset('/favicon.svg') }}" type="image/x-icon">

    <!-- Vendors styles-->
    <link href="{{ asset('assets/vendors/simplebar/simplebar.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/vendors/sweetalert/sweetalert.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/vendors/coreui/icons/css/free.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/simplebar.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/datatable.css') }}" rel="stylesheet">

    <!-- Main styles for this application-->
    <link href="{{ asset('assets/css/style.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/custom.css') }}" rel="stylesheet">
</head>

<body>
    <div class="bg-body-tertiary min-vh-100 d-flex flex-row align-items-center">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="card-group d-block d-md-flex row">
                        <div class="card col-md-7 p-4 mb-0">
                            <div class="card-body">
                                <h2>Login</h2>
                                <p class="text-body-secondary">Sign In to your account</p>

                                @error('auth_failed')
                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <small>Email atau password anda salah</small>
                                        <button type="button" class="btn-close" data-coreui-dismiss="alert"
                                            aria-label="Close"></button>
                                    </div>
                                @enderror

                                <form action="{{ route('authenticate') }}" method="post">
                                    @csrf
                                    <div class="form-group mb-3">
                                        <div class="input-group">
                                            <span class="input-group-text">
                                                <i class="cil-at"></i>
                                            </span>
                                            <input class="form-control" type="email" name="email"
                                                placeholder="Masukkkan Email" value="{{ old('email') }}">
                                        </div>
                                        @error('email')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>
                                    <div class="form-group mb-4">
                                        <div class="input-group">
                                            <span class="input-group-text">
                                                <i class="cil-lock-locked"></i>
                                            </span>
                                            <input class="form-control" type="password" name="password"
                                                placeholder="Masukkan Password" value="{{ old('password') }}">
                                        </div>
                                        @error('password')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <button class="btn btn-primary px-4" type="submit">
                                                Sign In
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="card col-md-5 text-white bg-primary py-5">
                            <div class="card-body">
                                <div>
                                    <h2>
                                        <i class="cil-3d"></i> Laravel
                                    </h2>
                                    <p>
                                        Aplikasi ini dibuat menggunakan framework Laravel 9, untuk dokumentasi lebih
                                        lanjut klik tombol dibawah ini.
                                    </p>
                                    <a href="https://laravel.com/docs/9.x/releases" class="btn btn-outline-light px-4">
                                        Dokumentasi
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- CoreUI and necessary plugins-->
    <script src="{{ asset('assets/js/config.js') }}"></script>
    <script src="{{ asset('assets/js/cookies.js') }}"></script>
    <script src="{{ asset('assets/vendors/coreui/core/coreui.bundle.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/simplebar/simplebar.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/jquery/jquery.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/datatable/datatable.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/datatable/datatable.bs5.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/sweetalert/sweetalert.min.js') }}"></script>

    <!-- Plugins and scripts required by this view-->
    <script src="{{ asset('assets/vendors/coreui/utils/index.js') }}"></script>
    <script>
        const baseUrl = (path) => "{{ url('/') }}" + path;
        const assetUrl = (path) => "{{ asset('/') }}" + path;
    </script>
</body>

</html>

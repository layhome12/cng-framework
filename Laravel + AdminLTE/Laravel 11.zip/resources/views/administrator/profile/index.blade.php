@extends('layout.main')
@section('css')
    <style>

    </style>
@endsection
@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Profile</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Profile</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <section class="content">
        <div class="container-fluid">
            <div class="card card-primary">
                <div class="card-header">
                    <div class="row justify-content-between align-items-center">
                        <div class="col-auto">
                            <h5 class="card-title">Data Profile</h5>
                        </div>
                        <div class="col-auto">
                            <a href="{{ route('profile.edit') }}" class="btn btn-light btn-sm text-dark">
                                <i class="fa fa-edit mr-2"></i> Edit
                            </a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-xl-auto">
                            <div class="row mx-0">
                                <label for="name" class="col-auto col-form-label">
                                    <i class="fa fa-arrow-right mr-1"></i> Name
                                </label>
                                <div class="col">
                                    <input type="text" readonly class="form-control-plaintext" id="name"
                                        value="{{ $profile->name }}">
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-auto">
                            <div class="row mx-0">
                                <label for="username" class="col-auto col-form-label">
                                    <i class="fa fa-arrow-right mr-1"></i> Username
                                </label>
                                <div class="col">
                                    <input type="text" readonly class="form-control-plaintext" id="username"
                                        value="{{ $profile->username }}">
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-auto">
                            <div class="row mx-0">
                                <label for="email" class="col-auto col-form-label">
                                    <i class="fa fa-arrow-right mr-1"></i> Email
                                </label>
                                <div class="col">
                                    <input type="text" readonly class="form-control-plaintext" id="email"
                                        value="{{ $profile->email }}">
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-auto">
                            <div class="row mx-0">
                                <label for="password" class="col-auto col-form-label">
                                    <i class="fa fa-arrow-right mr-1"></i> Password
                                </label>
                                <div class="col">
                                    <input type="text" readonly class="form-control-plaintext" id="password"
                                        value="{{ $profile->password }}">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
@section('js')
    @if (session()->has('dataSaved') && session()->get('dataSaved') == true)
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: '{{ session()->get('message') }}',
            });
        </script>
    @endif
    @if (session()->has('dataSaved') && session()->get('dataSaved') == false)
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: '{{ session()->get('message') }}',
            });
        </script>
    @endif
@endsection

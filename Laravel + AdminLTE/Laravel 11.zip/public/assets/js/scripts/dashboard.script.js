$(function () {
    "use strict";

    // Bar Chart
    var salesChartCanvas = document
        .getElementById("revenue-chart-canvas")
        .getContext("2d");

    var salesChartData = {
        labels: [
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun",
            "Jul",
            "Aug",
            "Sept",
            "Oct",
            "Nov",
            "Dec",
        ],
        datasets: [
            {
                label: "Online",
                backgroundColor: "rgba(60,141,188,0.9)",
                borderColor: "rgba(60,141,188,0.8)",
                pointRadius: false,
                pointColor: "#3b8bba",
                pointStrokeColor: "rgba(60,141,188,1)",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(60,141,188,1)",
                data: [28, 48, 40, 19, 86, 27, 90, 28, 48, 40, 19, 14],
            },
            {
                label: "Offline",
                backgroundColor: "rgba(210, 214, 222, 1)",
                borderColor: "rgba(210, 214, 222, 1)",
                pointRadius: false,
                pointColor: "rgba(210, 214, 222, 1)",
                pointStrokeColor: "#c1c7d1",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(220,220,220,1)",
                data: [65, 59, 80, 81, 56, 55, 40, 65, 59, 80, 81, 56],
            },
        ],
    };

    var salesChartOptions = {
        maintainAspectRatio: false,
        responsive: true,
        legend: {
            display: false,
        },
        scales: {
            xAxes: [
                {
                    gridLines: {
                        display: false,
                    },
                },
            ],
            yAxes: [
                {
                    gridLines: {
                        display: false,
                    },
                },
            ],
        },
    };

    // This will get the first returned node in the jQuery collection.
    new Chart(salesChartCanvas, {
        type: "line",
        data: salesChartData,
        options: salesChartOptions,
    });

    // Donut Chart
    var pieChartCanvas = $("#sales-chart-canvas").get(0).getContext("2d");
    var pieData = {
        labels: ["USA", "Brazil", "France", "BD", "UK", "India"],
        datasets: [
            {
                data: [30, 12, 20, 10, 15, 20],
                backgroundColor: [
                    "#71c6d4",
                    "#17a2b8",
                    "#71c6d4",
                    "#17a2b8",
                    "#71c6d4",
                    "#17a2b8",
                ],
            },
        ],
    };
    var pieOptions = {
        legend: {
            display: false,
        },
        maintainAspectRatio: false,
        responsive: true,
    };

    //Create pie or douhnut chart
    new Chart(pieChartCanvas, {
        type: "doughnut",
        data: pieData,
        options: pieOptions,
    });
});

<a href="#" class="brand-link">
    <img src="{{ asset('/favicon.svg') }}" class="brand-image img-circle"
        style="width:33px;filter: brightness(2) grayscale(1);opacity: 0.8;">
    <span class="brand-text font-weight-light">App Name</span>
</a>
<div class="sidebar">
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
            <img src="{{ asset('assets/img/placeholder.jpg') }}" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
            <a href="{{ route('profile.index') }}" class="d-block">Profile</a>
        </div>
    </div>

    <!-- Sidebar Menu -->
    <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
            <li class="nav-item">
                <a href="{{ route('dashboard') }}" class="nav-link {{ Route::is('dashboard') ? 'active' : '' }}">
                    <i class="nav-icon fas fa-home"></i>
                    <p>
                        Dashboard
                    </p>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link {{ Route::is('user.*') ? 'active' : '' }}" href="{{ route('user.index') }}">
                    <i class="nav-icon cil-menu"></i>
                    <p>User</p>
                </a>
            </li>
        </ul>
    </nav>
</div>
